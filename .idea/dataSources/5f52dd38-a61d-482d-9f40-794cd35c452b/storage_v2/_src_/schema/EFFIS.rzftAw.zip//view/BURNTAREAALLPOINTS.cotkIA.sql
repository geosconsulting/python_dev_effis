create view BURNTAREAALLPOINTS as
  select sdo_geom.sdo_centroid(tb.ora_geometry, m.diminfo) as geom, tb.CLASS, tb.OGR_FID  from rdaprd.AllBurntAreasPoly tb, (select diminfo from all_sdo_geom_metadata  where owner = 'RDAPRD' and table_name = 'ALLBURNTAREASPOLY') m
/

