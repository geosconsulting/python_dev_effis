create materialized view BURNTAREAPOINT_MV
refresh complete on demand
  as
    select tb.CLASS, tb.OGR_FID, tb.FIREDATE,tb.LASTUPDATE,tb.COUNTRY,tb.COUNTRYFUL,tb.PROVINCE,tb.COMMUNE,tb.AREA_HA,tb.BROADLEA,tb.CONIFER,tb.MIXED,tb.SCLEROPH,tb.TRANSIT,tb.OTHERNATLC,tb.AGRIAREAS,tb.ARTIFSURF,tb.OTHERLC, sdo_geom.sdo_centroid(tb.ora_geometry, m.diminfo) as geom from ALLBURNTAREASPOLY tb,
 (select diminfo from all_sdo_geom_metadata 
  where   table_name = 'ALLBURNTAREASPOLY') m
/

