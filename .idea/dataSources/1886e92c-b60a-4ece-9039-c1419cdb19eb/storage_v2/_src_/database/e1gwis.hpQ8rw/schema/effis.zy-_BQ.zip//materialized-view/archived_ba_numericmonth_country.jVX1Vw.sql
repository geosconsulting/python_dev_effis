CREATE MATERIALIZED VIEW archived_ba_numericmonth_country AS SELECT archived_ba.countryfullname AS "Country",
    date_part('month'::text, (archived_ba.firedate)::date) AS "Month",
    sum(archived_ba.area_ha) AS area_hectares
   FROM effis.archived_ba
  GROUP BY (date_part('month'::text, (archived_ba.firedate)::date)), archived_ba.countryfullname
  ORDER BY (date_part('month'::text, (archived_ba.firedate)::date));

