CREATE MATERIALIZED VIEW archived_ba_country_totals AS SELECT archived_ba_country_year."Country",
    archived_ba_country_year."Number of Fires",
    archived_ba_country_year."Sum Ha Burnt Area"
   FROM effis.archived_ba_country_year
  WHERE (archived_ba_country_year."Year" IS NULL);

