create function trunc(numeric)
  returns numeric
immutable
strict
parallel safe
cost 1
language sql
as $$
select pg_catalog.trunc($1,0)
$$;

