create view current_ba_country_total_by_month as
  SELECT current_ba.countryful AS "Country",
    to_char(to_timestamp((date_part('month'::text, (current_ba.firedate)::date))::text, 'MM'::text), 'Month'::text) AS "Month",
    sum(current_ba.area_ha) AS area_ettari
   FROM effis.current_ba
  GROUP BY ROLLUP((to_char(to_timestamp((date_part('month'::text, (current_ba.firedate)::date))::text, 'MM'::text), 'Month'::text)), current_ba.countryful);

