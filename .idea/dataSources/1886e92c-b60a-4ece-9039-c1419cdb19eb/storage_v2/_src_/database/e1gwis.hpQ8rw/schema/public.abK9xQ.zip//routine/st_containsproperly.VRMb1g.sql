create function st_containsproperly(geom1 geometry, geom2 geometry)
  returns boolean
immutable
parallel safe
language sql
as $$
SELECT $1 OPERATOR(public.~) $2 AND public._ST_ContainsProperly($1,$2)
$$;

