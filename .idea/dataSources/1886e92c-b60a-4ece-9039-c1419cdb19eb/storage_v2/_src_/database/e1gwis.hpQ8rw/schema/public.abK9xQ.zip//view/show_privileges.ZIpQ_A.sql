create view show_privileges as
  SELECT t.grantee,
    string_agg((t.relname)::text, ', '::text ORDER BY ((t.relname)::text)) AS rel_names,
    t.privileges
   FROM ( SELECT pg_class.relname,
            COALESCE(NULLIF(s.s[1], ''::text), 'public'::text) AS grantee,
            ( SELECT string_agg(s_1.privilege, ', '::text ORDER BY s_1.privilege) AS string_agg
                   FROM ( SELECT
                                CASE ch.ch
                                    WHEN 'r'::text THEN 'SELECT'::text
                                    WHEN 'w'::text THEN 'UPDATE'::text
                                    WHEN 'a'::text THEN 'INSERT'::text
                                    WHEN 'd'::text THEN 'DELETE'::text
                                    WHEN 'D'::text THEN 'TRUNCATE'::text
                                    WHEN 'x'::text THEN 'REFERENCES'::text
                                    WHEN 't'::text THEN 'TRIGGER'::text
                                    ELSE NULL::text
                                END AS privilege
                           FROM regexp_split_to_table(s.s[2], ''::text) ch(ch)) s_1) AS privileges
           FROM ((pg_class
             JOIN pg_namespace ON ((pg_namespace.oid = pg_class.relnamespace)))
             JOIN pg_roles ON ((pg_roles.oid = pg_class.relowner))),
            LATERAL unnest(COALESCE((pg_class.relacl)::text[], (format('{%s=arwdDxt/%s}'::text, pg_roles.rolname, pg_roles.rolname))::text[])) acl(acl),
            LATERAL regexp_split_to_array(acl.acl, '=|/'::text) s(s)
          WHERE (pg_namespace.nspname = 'public'::name)) t
  GROUP BY t.grantee, t.privileges
  ORDER BY t.grantee, t.privileges, (string_agg((t.relname)::text, ', '::text ORDER BY ((t.relname)::text)));

