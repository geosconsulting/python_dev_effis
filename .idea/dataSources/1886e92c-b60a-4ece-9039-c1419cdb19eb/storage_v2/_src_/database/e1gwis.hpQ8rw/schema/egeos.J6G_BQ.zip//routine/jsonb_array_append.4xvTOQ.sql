create function jsonb_array_append(j jsonb, e text)
  returns jsonb
immutable
language sql
as $$
select array_to_json(array_append(array(select * from jsonb_array_elements_text(j)), e))::jsonb
$$;

