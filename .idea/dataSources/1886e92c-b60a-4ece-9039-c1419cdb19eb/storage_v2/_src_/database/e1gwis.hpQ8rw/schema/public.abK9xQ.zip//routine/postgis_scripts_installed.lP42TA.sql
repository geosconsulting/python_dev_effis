create function postgis_scripts_installed()
  returns text
immutable
language sql
as $$
SELECT '2.3.2'::text || ' r' || 15302::text AS version
$$;

