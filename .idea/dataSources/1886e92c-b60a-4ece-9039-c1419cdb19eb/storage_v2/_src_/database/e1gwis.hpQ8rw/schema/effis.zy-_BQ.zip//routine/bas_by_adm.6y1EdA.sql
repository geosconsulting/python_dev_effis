create function bas_by_adm(admin_level integer, adm_name character varying)
  returns TABLE(name_adm character varying, f_id integer, firedate date, update date, area_ha integer)
language plpgsql
as $$
DECLARE
    admin_level_table varchar := 'public.admin_level_' || admin_level;
    adm_id varchar := 'adm' || admin_level ||'_id';    
    query varchar :=  'SELECT a.name_local, 
                              b.ba_id, 
                              b.firedate::date, 
                              b.lastupdate::date,
                              b.area_ha
                       FROM effis.current_burnt_area b ' || 
                         ' LEFT JOIN '|| admin_level_table || ' a ON ST_Contains(a.geom, b.geom)' ||
                         ' WHERE a.name_en =''' || adm_name ||''';';
BEGIN
   RETURN QUERY
      EXECUTE query;           
   --RAISE NOTICE 'query %' , query;
END;
$$;

