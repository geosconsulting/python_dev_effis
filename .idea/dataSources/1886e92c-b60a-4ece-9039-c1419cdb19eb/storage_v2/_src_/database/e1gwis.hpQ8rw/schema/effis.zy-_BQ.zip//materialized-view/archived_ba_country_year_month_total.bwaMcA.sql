CREATE MATERIALIZED VIEW archived_ba_country_year_month_total AS SELECT archived_ba.countryfullname AS "Country",
    date_part('year'::text, (archived_ba.firedate)::date) AS "Year",
    date_part('month'::text, (archived_ba.firedate)::date) AS "Month",
    sum(archived_ba.area_ha) AS area_ettari
   FROM effis.archived_ba
  GROUP BY CUBE(((date_part('year'::text, (archived_ba.firedate)::date)), (date_part('month'::text, (archived_ba.firedate)::date))), archived_ba.countryfullname);

