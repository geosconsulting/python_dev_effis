create function dropgeometrytable(schema_name character varying, table_name character varying)
  returns text
strict
language sql
as $$
SELECT DropGeometryTable('',$1,$2)
$$;

