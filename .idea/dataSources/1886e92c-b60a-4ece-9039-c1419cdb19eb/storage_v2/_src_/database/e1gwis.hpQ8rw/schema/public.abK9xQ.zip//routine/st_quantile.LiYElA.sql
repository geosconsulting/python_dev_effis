create function st_quantile(rast raster, exclude_nodata_value boolean, quantile double precision DEFAULT NULL::double precision)
  returns double precision
immutable
parallel safe
language sql
as $$
SELECT ( public._ST_quantile($1, 1, $2, 1, ARRAY[$3]::double precision[])).value
$$;

