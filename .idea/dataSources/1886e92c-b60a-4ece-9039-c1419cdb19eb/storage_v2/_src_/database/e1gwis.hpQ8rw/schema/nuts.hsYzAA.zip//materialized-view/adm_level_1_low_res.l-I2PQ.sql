CREATE MATERIALIZED VIEW adm_level_1_low_res AS SELECT l1.id,
    attr.cntr_code,
    l1.nuts_id,
    l1.stat_levl_,
    attr.name_latn,
    attr.nuts_name,
    attr.name_ascii,
    l1.geom
   FROM nuts.nuts_rg_60m_2013_wgs84 l1,
    nuts.nuts_at_2013 attr
  WHERE ((l1.stat_levl_ = 1) AND ((attr.nuts_id)::text = (l1.nuts_id)::text));

