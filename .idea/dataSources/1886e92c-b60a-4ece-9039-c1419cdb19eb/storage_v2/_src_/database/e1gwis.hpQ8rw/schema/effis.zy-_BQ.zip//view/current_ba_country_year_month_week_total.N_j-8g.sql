create view current_ba_country_year_month_week_total as
  SELECT current_ba.countryful AS "Country",
    date_part('year'::text, (current_ba.firedate)::date) AS "Year",
    date_part('month'::text, (current_ba.firedate)::date) AS "Month",
    date_part('week'::text, (current_ba.firedate)::date) AS "Week",
    sum(current_ba.area_ha) AS area_hectares
   FROM effis.current_ba
  GROUP BY CUBE(((date_part('year'::text, (current_ba.firedate)::date)), (date_part('month'::text, (current_ba.firedate)::date)), (date_part('week'::text, (current_ba.firedate)::date))), current_ba.countryful);

