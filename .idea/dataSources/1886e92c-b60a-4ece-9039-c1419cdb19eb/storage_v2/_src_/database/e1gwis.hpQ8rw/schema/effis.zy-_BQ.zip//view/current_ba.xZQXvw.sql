create view current_ba as
  SELECT pba.ba_id,
    pba.area_ha,
    pba.firedate,
    pba.lastupdate,
    pba.geom,
    oba.id,
    oba.country,
    oba.countryful,
    oba.province,
    oba.commune,
    oba.broadlea,
    oba.conifer,
    oba.mixed,
    oba.scleroph,
    oba.transit,
    oba.othernatlc,
    oba.agriareas,
    oba.artifsurf,
    oba.otherlc,
    oba.percna2k,
    oba.class,
    oba.mic,
    oba.se_anno_cad_data,
    oba.critech
   FROM (effis.current_burnt_area pba
     LEFT JOIN rdaprd.current_burntareaspoly oba ON ((oba.id = pba.ba_id)));

