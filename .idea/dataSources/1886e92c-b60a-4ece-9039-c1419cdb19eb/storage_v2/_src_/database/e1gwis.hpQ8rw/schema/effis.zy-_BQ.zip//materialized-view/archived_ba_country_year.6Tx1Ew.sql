CREATE MATERIALIZED VIEW archived_ba_country_year AS SELECT archived_ba.countryfullname AS "Country",
    date_part('year'::text, (archived_ba.firedate)::date) AS "Year",
    count(archived_ba.yearid) AS "Number of Fires",
    sum(archived_ba.area_ha) AS "Sum Ha Burnt Area"
   FROM effis.archived_ba
  GROUP BY GROUPING SETS ((archived_ba.countryfullname, (date_part('year'::text, (archived_ba.firedate)::date))), (archived_ba.countryfullname));

