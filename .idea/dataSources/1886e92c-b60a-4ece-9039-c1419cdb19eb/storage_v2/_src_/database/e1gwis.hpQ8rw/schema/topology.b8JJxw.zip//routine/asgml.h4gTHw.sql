create function asgml(tg topogeometry, visitedtable regclass)
  returns text
language sql
as $$
SELECT topology.AsGML($1, 'gml', 15, 1, $2);
$$;

