create function link_current_evolution()
  returns TABLE(current_id bigint, date_current date, current_area_ha numeric, evolution_firedate date, evolution_area_ha numeric, difference double precision)
language plpgsql
as $$
begin 
   return QUERY
     SELECT c.id,c.firedate,c.area_ha,e.firedate,e.area_ha,cast(c.area_ha-e.area_ha as double precision) as "increase"
     from egeos.current_ba c
     INNER join egeos.evolution_ba e ON (e.id=c.id)
     ORDER BY c.id;
end;
$$;

