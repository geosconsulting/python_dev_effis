create function postgis_raster_scripts_installed()
  returns text
immutable
parallel safe
language sql
as $$
SELECT '2.3.2'::text || ' r' || 15302::text AS version
$$;

