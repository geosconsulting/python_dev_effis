create function st_summarystats(rastertable text, rastercolumn text, exclude_nodata_value boolean)
  returns summarystats
stable
strict
language sql
as $$
SELECT public._ST_summarystats($1, $2, 1, $3, 1)
$$;

