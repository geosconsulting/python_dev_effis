CREATE MATERIALIZED VIEW adm_level_2_high_res AS SELECT l2.id,
    attr.cntr_code,
    l2.nuts_id,
    l2.stat_levl_,
    attr.name_latn,
    attr.nuts_name,
    attr.name_ascii,
    l2.geom
   FROM nuts.nuts_rg_01m_2013_wgs84 l2,
    nuts.nuts_at_2013 attr
  WHERE ((l2.stat_levl_ = 2) AND ((attr.nuts_id)::text = (l2.nuts_id)::text));

