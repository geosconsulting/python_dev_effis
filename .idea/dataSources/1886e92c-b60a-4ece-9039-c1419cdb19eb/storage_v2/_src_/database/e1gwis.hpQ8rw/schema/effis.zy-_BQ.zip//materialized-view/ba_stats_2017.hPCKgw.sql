CREATE MATERIALIZED VIEW ba_stats_2017 AS SELECT a.name_en,
    date_part('year'::text, (b.firedate)::date) AS year_date,
    date_part('month'::text, (b.firedate)::date) AS month_date,
    sum((st_area((b.geom)::geography) * (0.0001)::double precision)) AS sum,
    count(b.ba_id) AS count
   FROM effis.archived_burnt_area b,
    effis_countries a
  WHERE (((b.firedate)::date >= '2017-01-01'::date) AND ((b.firedate)::date <= '2017-12-31'::date) AND st_intersects(b.geom, a.geom))
  GROUP BY CUBE(((date_part('year'::text, (b.firedate)::date)), (date_part('month'::text, (b.firedate)::date))), a.name_en);

