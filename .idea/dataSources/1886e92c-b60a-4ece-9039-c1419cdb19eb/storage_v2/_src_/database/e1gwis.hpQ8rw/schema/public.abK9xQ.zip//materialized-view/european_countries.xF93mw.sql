CREATE MATERIALIZED VIEW european_countries AS SELECT mm_ma.id,
    adm.name_en,
    ma.name,
    adm.geom
   FROM ((admin_level_0_macroareas mm_ma
     LEFT JOIN admin_level_0 adm ON ((adm.id = mm_ma.country_id)))
     LEFT JOIN macroareas ma ON ((ma.id = mm_ma.macroarea_id)))
  WHERE ((ma.name)::text = 'EU'::text);

