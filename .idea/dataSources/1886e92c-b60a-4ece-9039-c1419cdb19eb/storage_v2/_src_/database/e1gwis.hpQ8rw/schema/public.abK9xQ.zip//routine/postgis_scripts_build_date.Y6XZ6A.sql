create function postgis_scripts_build_date()
  returns text
immutable
language sql
as $$
SELECT '2017-01-31 16:32:46'::text AS version
$$;

