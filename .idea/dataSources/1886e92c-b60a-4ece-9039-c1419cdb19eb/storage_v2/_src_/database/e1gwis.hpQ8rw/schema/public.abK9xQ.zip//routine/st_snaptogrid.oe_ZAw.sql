create function st_snaptogrid(geometry, double precision)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT public.ST_SnapToGrid($1, 0, 0, $2, $2)
$$;

