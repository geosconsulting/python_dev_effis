create view modis_burnt_areas as
  SELECT
        CASE
            WHEN (date_part('year'::text, (archived_and_current.firedate)::date) IS NULL) THEN ('9999_'::text || archived_and_current.ba_id)
            ELSE ((date_part('year'::text, (archived_and_current.firedate)::date) || '_'::text) || archived_and_current.ba_id)
        END AS global_id,
    archived_and_current.ba_id,
    archived_and_current.area_ha,
    archived_and_current.firedate,
    archived_and_current.lastupdate,
    archived_and_current.geom
   FROM ( SELECT current_burnt_area.ba_id,
            current_burnt_area.area_ha,
            current_burnt_area.firedate,
            current_burnt_area.lastupdate,
            current_burnt_area.geom
           FROM effis.current_burnt_area
        UNION
         SELECT archived_burnt_area.ba_id,
            archived_burnt_area.area_ha,
            archived_burnt_area.firedate,
            archived_burnt_area.lastupdate,
            archived_burnt_area.geom
           FROM effis.archived_burnt_area) archived_and_current;

