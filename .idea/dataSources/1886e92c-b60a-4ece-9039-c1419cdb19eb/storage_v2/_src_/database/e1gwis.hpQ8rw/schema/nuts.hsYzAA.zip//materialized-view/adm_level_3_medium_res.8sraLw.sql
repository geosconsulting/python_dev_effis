CREATE MATERIALIZED VIEW adm_level_3_medium_res AS SELECT l3.id,
    attr.cntr_code,
    l3.nuts_id,
    l3.stat_levl_,
    attr.name_latn,
    attr.nuts_name,
    attr.name_ascii,
    l3.geom
   FROM nuts.nuts_rg_10m_2013_wgs84 l3,
    nuts.nuts_at_2013 attr
  WHERE ((l3.stat_levl_ = 3) AND ((attr.nuts_id)::text = (l3.nuts_id)::text));

