CREATE MATERIALIZED VIEW archived_ba_country_total_by_month AS SELECT archived_ba.countryfullname AS "Country",
    to_char(to_timestamp((date_part('month'::text, (archived_ba.firedate)::date))::text, 'MM'::text), 'Month'::text) AS "Month",
    sum(archived_ba.area_ha) AS area_ettari
   FROM effis.archived_ba
  GROUP BY ROLLUP((to_char(to_timestamp((date_part('month'::text, (archived_ba.firedate)::date))::text, 'MM'::text), 'Month'::text)), archived_ba.countryfullname);

