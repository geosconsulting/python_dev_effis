create function st_aspng(rast raster, nband integer, compression integer)
  returns bytea
immutable
strict
parallel safe
language sql
as $$
SELECT st_aspng($1, ARRAY[$2], $3)
$$;

