create function postgis_scripts_build_date()
  returns text
immutable
language sql
as $$
SELECT '2017-07-24 10:54:08'::text AS version
$$;

