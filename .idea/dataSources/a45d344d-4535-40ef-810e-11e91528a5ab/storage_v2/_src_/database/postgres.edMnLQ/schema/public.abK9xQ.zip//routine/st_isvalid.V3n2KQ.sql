create function st_isvalid(geometry, integer)
  returns boolean
immutable
strict
parallel safe
language sql
as $$
SELECT (public.ST_isValidDetail($1, $2)).valid
$$;

