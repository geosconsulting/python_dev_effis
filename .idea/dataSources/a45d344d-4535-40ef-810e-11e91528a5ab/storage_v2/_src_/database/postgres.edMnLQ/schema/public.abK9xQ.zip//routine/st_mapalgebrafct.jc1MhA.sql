create function st_mapalgebrafct(rast raster, band integer, pixeltype text, onerastuserfunc regprocedure)
  returns raster
language sql
as $$
SELECT public.ST_mapalgebrafct($1, $2, $3, $4, NULL)
$$;

