create function postgis_scripts_installed()
  returns text
immutable
language sql
as $$
SELECT '2.3.3'::text || ' r' || 15473::text AS version
$$;

