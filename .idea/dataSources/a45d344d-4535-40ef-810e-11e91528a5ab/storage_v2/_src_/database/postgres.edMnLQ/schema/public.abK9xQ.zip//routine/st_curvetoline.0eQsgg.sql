create function st_curvetoline(geometry)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT ST_CurveToLine($1, 32)
$$;

