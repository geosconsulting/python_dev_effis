create function postgis_raster_scripts_installed()
  returns text
immutable
parallel safe
language sql
as $$
SELECT '2.3.3'::text || ' r' || 15473::text AS version
$$;

