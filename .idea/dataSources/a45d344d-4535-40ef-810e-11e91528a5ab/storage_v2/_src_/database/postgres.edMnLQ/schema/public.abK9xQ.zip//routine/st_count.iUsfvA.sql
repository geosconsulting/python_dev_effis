create function st_count(rast raster, exclude_nodata_value boolean)
  returns bigint
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_count($1, 1, $2, 1)
$$;

