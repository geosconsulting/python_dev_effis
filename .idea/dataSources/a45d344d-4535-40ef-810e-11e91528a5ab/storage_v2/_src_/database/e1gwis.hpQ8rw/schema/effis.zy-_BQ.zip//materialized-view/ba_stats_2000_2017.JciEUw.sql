CREATE MATERIALIZED VIEW ba_stats_2000_2017 AS SELECT DISTINCT rob_burntareas_history.yearseason,
    rob_burntareas_history.country,
    count(rob_burntareas_history.id) OVER w AS "Number of Fires",
    sum(rob_burntareas_history.area_ha) OVER w AS "Summed Hectares"
   FROM rdaprd.rob_burntareas_history
  WINDOW w AS (PARTITION BY rob_burntareas_history.yearseason, rob_burntareas_history.country);

