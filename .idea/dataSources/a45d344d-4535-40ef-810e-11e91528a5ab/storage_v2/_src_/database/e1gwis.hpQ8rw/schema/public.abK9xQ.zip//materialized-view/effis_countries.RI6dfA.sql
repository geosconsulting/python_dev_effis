CREATE MATERIALIZED VIEW effis_countries AS SELECT row_number() OVER (ORDER BY adm.iso2 DESC) AS oid,
    adm.iso2,
    adm.iso,
    adm.name_en,
    adm.geom
   FROM admin_level_0 adm
  WHERE ((adm.iso)::text = ANY (ARRAY['ALB'::text, 'DZA'::text, 'BEL'::text, 'BIH'::text, 'BGR'::text, 'CYP'::text, 'FRA'::text, 'HRV'::text, 'DEU'::text, 'GRC'::text, 'IRL'::text, 'ISR'::text, 'ITA'::text, 'XKO'::text, 'MKD'::text, 'MNE'::text, 'MAR'::text, 'XNC'::text, 'PSE'::text, 'PRT'::text, 'ROU'::text, 'SRB'::text, 'SVN'::text, 'ESP'::text, 'SWE'::text, 'SYR'::text, 'TUN'::text, 'TUR'::text, 'GBR'::text]));

