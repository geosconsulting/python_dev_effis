create function st_curvetoline(geometry, integer)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT ST_CurveToLine($1, $2::float8, 0, 0)
$$;

