create function generate_annual_stats(year_int integer)
  returns void
language plpgsql
as $$
declare 
  view_name text := 'ba_stats_' || year_int;
begin
CREATE MATERIALIZED VIEW effis.view_name AS 
 SELECT a.name_en,
    date_part('year'::text, b.firedate::date) AS year_date,
    date_part('month'::text, b.firedate::date) AS month_date,
    sum(st_area(b.geom::geography) * 0.0001::double precision) AS sum,
    count(b.ba_id) AS count
   FROM effis.archived_burnt_area b,
    effis_countries a
  WHERE b.firedate::date >= year_int || '-01-01'::date AND b.firedate::date <= year_int || '-12-31'::date AND st_intersects(b.geom, a.geom)
  GROUP BY CUBE(((date_part('year'::text, b.firedate::date)), (date_part('month'::text, b.firedate::date))), a.name_en);
end;
$$;

