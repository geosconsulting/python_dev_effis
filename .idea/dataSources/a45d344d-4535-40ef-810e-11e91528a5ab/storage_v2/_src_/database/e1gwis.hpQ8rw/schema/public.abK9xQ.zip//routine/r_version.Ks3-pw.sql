create function r_version()
  returns SETOF r_version_type
language plr
as $$
  cbind(names(version),unlist(version))
$$;

