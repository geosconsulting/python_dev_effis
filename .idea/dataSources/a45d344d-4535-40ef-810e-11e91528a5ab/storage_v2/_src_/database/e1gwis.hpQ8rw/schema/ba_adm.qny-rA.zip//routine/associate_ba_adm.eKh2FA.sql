create function associate_ba_adm(admin_level integer)
  returns void
language plpgsql
as $$
DECLARE
    admin_level_table varchar := 'public.admin_level_' || admin_level;    
    adm_mm varchar := 'ba_adm.ba_adm' || admin_level;
    fld_ba text := 'fire_id';
    fld_adm text := 'adm' || admin_level || '_id';
    query varchar :=  'INSERT INTO ' || adm_mm || '(' || fld_ba || ',' || fld_adm || ')' ||
                      ' SELECT ba.id,ad.id FROM rdaprd.current_burntareaspoly ba' || 
                      ' LEFT JOIN public.admin_level_' || admin_level || ' ad ON ST_Intersects(ba.shape,ad.geom);'; 
BEGIN   
   RAISE NOTICE 'query %', query;
   EXECUTE query;              
END;
$$;

