create function adm2_by_fireid_with_areas(code integer)
  returns TABLE(f_id integer, adm2_code integer, firedate character varying, update character varying, name_adm2 character varying, area double precision)
language plpgsql
as $$
BEGIN
   RETURN QUERY
     SELECT p.id,b.id,b.firedate,b.lastupdate,p.name_local,ST_Area(ST_Intersection(b.geom, p.geom)) As area_intersection
     FROM effis.burnt_area_spatial b       
     INNER JOIN public.countries_adminsublevel2 p ON ST_Intersects(b.geom,p.geom)
     WHERE b.id = code
     ORDER BY area_intersection DESC;
END;
$$;

