create function bit_length(bit)
  returns integer
immutable
strict
parallel safe
cost 1
language sql
as $$
select pg_catalog.length($1)
$$;

