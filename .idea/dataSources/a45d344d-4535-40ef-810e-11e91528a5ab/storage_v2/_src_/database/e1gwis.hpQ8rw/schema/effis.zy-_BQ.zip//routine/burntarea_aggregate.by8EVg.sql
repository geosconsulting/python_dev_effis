create function burntarea_aggregate(country_txt text, from_date date, to_date date, split character varying)
  returns TABLE(id integer, fire_date date, conifer numeric, broadleaf numeric, mixed numeric)
language plpgsql
as $$
BEGIN
     RETURN QUERY
     SELECT ba.id, ba.firedate, ba.conifer, ba.broadlea , ba.mixed 
     FROM public.burnt_area ba, public.countries_country_simple cnt
     WHERE cnt.name_en = country_txt  
     AND firedate BETWEEN(from_date) AND (to_date)
     AND ST_Within(ba.geom, cnt.geom);  
END;
$$;

