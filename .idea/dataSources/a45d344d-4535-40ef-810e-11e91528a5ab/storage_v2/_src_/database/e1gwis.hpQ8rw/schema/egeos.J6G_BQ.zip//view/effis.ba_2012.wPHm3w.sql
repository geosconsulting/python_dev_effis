create view "effis.ba_2012" as
  SELECT archived_burnt_area.id_source,
    archived_burnt_area.year_id,
    archived_burnt_area.ba_id,
    archived_burnt_area.area_ha,
    archived_burnt_area.firedate,
    archived_burnt_area.lastupdate,
    archived_burnt_area.geom,
    archived_burnt_area.id
   FROM effis.archived_burnt_area
  WHERE (((archived_burnt_area.firedate)::text >= '2012-01-01'::text) AND ((archived_burnt_area.firedate)::text <= '2012-12-31'::text));

