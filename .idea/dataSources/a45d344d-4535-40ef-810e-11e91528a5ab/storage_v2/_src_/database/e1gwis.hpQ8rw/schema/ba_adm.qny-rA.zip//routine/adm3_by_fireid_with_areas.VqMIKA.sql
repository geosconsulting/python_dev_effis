create function adm3_by_fireid_with_areas(code integer)
  returns TABLE(f_id integer, adm3_code integer, firedate character varying, update character varying, name_adm3 character varying, area double precision)
language plpgsql
as $$
BEGIN
   RETURN QUERY
     SELECT p.id,b.id,b.firedate,b.lastupdate,p.name_local,ST_Area(ST_Intersection(b.geom, p.geom)) As area_intersection
     FROM effis.burnt_area_spatial b       
	INNER JOIN public.countries_adminsublevel3 p ON ST_Intersects(b.geom,p.geom)
     WHERE b.id = code
     ORDER BY area_intersection DESC;
END;
$$;

