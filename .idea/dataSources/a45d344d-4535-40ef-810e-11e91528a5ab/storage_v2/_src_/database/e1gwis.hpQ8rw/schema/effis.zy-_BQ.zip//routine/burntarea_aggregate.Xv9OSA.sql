create function burntarea_aggregate(country_txt text, from_date date, to_date date)
  returns TABLE(num_ba bigint, summed_area double precision)
language plpgsql
as $$
BEGIN
     RETURN QUERY
     SELECT COUNT(ba.geom), 
	SUM(ST_Area(ba.geom))
     FROM effis.current_burnt_area ba, effis.admin_level_0 cnt
     WHERE cnt.name_en = country_txt  
     AND firedate BETWEEN(from_date) AND (to_date)
     AND ST_Within(ba.geom, cnt.geom);  
END;
$$;

