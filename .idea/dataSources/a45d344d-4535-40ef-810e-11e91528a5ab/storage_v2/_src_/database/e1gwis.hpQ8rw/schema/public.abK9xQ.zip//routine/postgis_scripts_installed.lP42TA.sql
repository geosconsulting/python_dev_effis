create function postgis_scripts_installed()
  returns text
immutable
language sql
as $$
SELECT '2.4.4'::text || ' r' || 16526::text AS version
$$;

