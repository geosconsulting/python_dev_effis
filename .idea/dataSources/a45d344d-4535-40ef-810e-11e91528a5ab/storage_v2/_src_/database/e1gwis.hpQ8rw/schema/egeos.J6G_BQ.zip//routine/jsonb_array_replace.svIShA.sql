create function jsonb_array_replace(j jsonb, e1 text, e2 text)
  returns jsonb
immutable
language sql
as $$
select array_to_json(array_replace(array(select * from jsonb_array_elements_text(j)), e1, e2))::jsonb
$$;

