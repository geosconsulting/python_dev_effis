create function load_r_typenames()
  returns text
language plr
as $$
  sql <- "select upper(typname::text) || 'OID' as typename, oid from pg_catalog.pg_type where typtype = 'b' order by typname"
  rs <- pg.spi.exec(sql)
  for(i in 1:nrow(rs))
  {
    typobj <- rs[i,1]
    typval <- rs[i,2]
    if (substr(typobj,1,1) == "_")
      typobj <- paste("ARRAYOF", substr(typobj,2,nchar(typobj)), sep="")
    assign(typobj, typval, .GlobalEnv)
  }
  return("OK")
$$;

