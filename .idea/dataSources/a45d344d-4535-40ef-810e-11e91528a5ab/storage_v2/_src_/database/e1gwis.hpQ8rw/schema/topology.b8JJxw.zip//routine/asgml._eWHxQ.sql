create function asgml(tg topogeometry, nsprefix text, prec integer, options integer, visitedtable regclass, idprefix text)
  returns text
language sql
as $$
SELECT topology.AsGML($1, $2, $3, $4, $5, $6, 3);
$$;

