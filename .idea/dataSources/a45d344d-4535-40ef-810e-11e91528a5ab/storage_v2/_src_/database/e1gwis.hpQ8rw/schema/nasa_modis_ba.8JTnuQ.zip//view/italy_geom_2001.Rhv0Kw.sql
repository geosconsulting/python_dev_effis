create view italy_geom_2001 as
  SELECT b.id,
    b.geom
   FROM nasa_modis_ba.final_ba b,
    admin_level_0 a
  WHERE (((b.initialdate >= '2001-01-01'::date) AND (b.initialdate <= '2012-12-31'::date)) AND ((a.name_local)::text = 'Italia'::text) AND st_intersects(a.geom, b.geom));

