CREATE MATERIALIZED VIEW ba_stats_206_comparison AS SELECT ba_stats_2016.name_en,
    ba_stats_2016.sum,
    ba_stats_2016.count
   FROM effis.ba_stats_2016
  WHERE ((ba_stats_2016.year_date IS NULL) AND (ba_stats_2016.month_date IS NULL));

