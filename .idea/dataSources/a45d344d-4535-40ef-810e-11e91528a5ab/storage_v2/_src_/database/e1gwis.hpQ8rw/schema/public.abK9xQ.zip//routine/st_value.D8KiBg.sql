create function st_value(rast raster, x integer, y integer, exclude_nodata_value boolean DEFAULT true)
  returns double precision
immutable
strict
parallel safe
language sql
as $$
SELECT st_value($1, 1, $2, $3, $4)
$$;

