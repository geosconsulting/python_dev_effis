CREATE MATERIALIZED VIEW effis_countries_extended AS SELECT row_number() OVER (ORDER BY adm.iso2 DESC) AS oid,
    adm.iso2,
    adm.iso,
    adm.name_en,
    adm.geom
   FROM admin_level_0 adm
  WHERE ((adm.iso)::text = ANY (ARRAY['ALB'::text, 'DZA'::text, 'BEL'::text, 'BIH'::text, 'BGR'::text, 'HRV'::text, 'CYP'::text, 'CZE'::text, 'DNK'::text, 'EGY'::text, 'EST'::text, 'FIN'::text, 'FRA'::text, 'GEO'::text, 'DEU'::text, 'GRC'::text, 'HUN'::text, 'ISL'::text, 'IRL'::text, 'ISR'::text, 'ITA'::text, 'JOR'::text, 'XKO'::text, 'LVA'::text, 'LBN'::text, 'LBY'::text, 'LTU'::text, 'LUX'::text, 'MAC'::text, 'MKD'::text, 'MDA'::text, 'MNE'::text, 'MAR'::text, 'NLD'::text, 'XNC'::text, 'NOR'::text, 'PSE'::text, 'POL'::text, 'PRT'::text, 'ROU'::text, 'SRB'::text, 'SVK'::text, 'SVN'::text, 'ESP'::text, 'SWE'::text, 'CHE'::text, 'SYR'::text, 'TUN'::text, 'TUR'::text, 'UKR'::text, 'GBR'::text]));

