create view v_modis_hotspots_italy as
  SELECT a.iso,
    a.name_iso,
    a.name_local,
    f.acq_date,
    f.geom
   FROM admin_level_0 a,
    modis_viirs.modis f
  WHERE (((a.iso)::text = 'ITA'::text) AND st_intersects(a.geom, f.geom));

