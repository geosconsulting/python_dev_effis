create view europa_stats_2001 as
  SELECT a.name_en,
    count(b.id) AS count,
    sum((st_area((b.geom)::geography) * (0.0001)::double precision)) AS sum
   FROM nasa_modis_ba.final_ba b,
    european_countries a
  WHERE (((b.initialdate >= '2001-01-01'::date) AND (b.initialdate <= '2001-12-31'::date)) AND st_within(b.geom, a.geom))
  GROUP BY a.name_en;

