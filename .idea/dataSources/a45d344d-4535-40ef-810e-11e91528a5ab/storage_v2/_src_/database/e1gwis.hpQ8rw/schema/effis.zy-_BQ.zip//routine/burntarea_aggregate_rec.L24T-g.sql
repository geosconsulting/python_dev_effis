create function burntarea_aggregate_rec(country_txt text, from_date date, to_date date, OUT num_ba bigint, OUT sum_area_ba double precision)
  returns record
language plpgsql
as $$
BEGIN 
     SELECT COUNT(ba.geom), SUM(ST_Area(ba.geom))
     INTO num_ba, sum_area_ba
     FROM public.current_burnt_area ba, effis.admin_level_0 cnt
     WHERE cnt.name_en = country_txt  
     AND firedate BETWEEN(from_date) AND (to_date)
     AND ST_Within(ba.geom, cnt.geom);  
END;
$$;

