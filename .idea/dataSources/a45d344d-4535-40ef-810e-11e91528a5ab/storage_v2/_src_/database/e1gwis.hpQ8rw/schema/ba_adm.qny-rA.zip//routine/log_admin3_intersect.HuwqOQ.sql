create function log_admin3_intersect()
  returns trigger
language plpgsql
as $$
BEGIN
  INSERT INTO fire_admin_link.ba_adm3(fire_id,adm3_id)
	SELECT ca.ba_id,ad.id
	FROM effis.current_burnt_areas ca
	LEFT JOIN effis_ext_public.admin_level_3 ad
	       ON ST_Intersects(ca.geom,ad.geom)
	WHERE ca.id = NEW.id;
     RAISE NOTICE 'new id %',NEW.id;
  RETURN NEW;
END;
$$;

