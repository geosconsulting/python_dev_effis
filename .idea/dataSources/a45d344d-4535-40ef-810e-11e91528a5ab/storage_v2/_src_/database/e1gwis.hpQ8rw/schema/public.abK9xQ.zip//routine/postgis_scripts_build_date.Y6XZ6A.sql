create function postgis_scripts_build_date()
  returns text
immutable
language sql
as $$
SELECT '2018-04-09 14:12:06'::text AS version
$$;

