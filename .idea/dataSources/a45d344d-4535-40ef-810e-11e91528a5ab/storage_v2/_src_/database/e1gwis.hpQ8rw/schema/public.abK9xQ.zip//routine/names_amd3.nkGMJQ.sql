create function names_amd3(adm_name character varying)
  returns TABLE(name_iso character varying, name_local character varying)
language plpgsql
as $$
BEGIN
 RETURN QUERY SELECT
	cnt.name_iso, adm1.name_local 
	FROM countries_adminsublevel1 adm1 
	RIGHT JOIN countries_country cnt ON adm1.country_id = cnt.id 
	WHERE adm1.name_local LIKE adm_name;
END;
$$;

