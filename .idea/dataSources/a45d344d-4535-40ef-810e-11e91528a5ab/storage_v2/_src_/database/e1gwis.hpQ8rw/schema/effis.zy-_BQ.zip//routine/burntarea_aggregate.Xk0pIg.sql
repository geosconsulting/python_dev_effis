create function burntarea_aggregate(country_txt text)
  returns TABLE(num_ba bigint, summed_area double precision)
language plpgsql
as $$
BEGIN
     RETURN QUERY
     SELECT COUNT(ba.geom), 
	SUM(ST_Area(ba.geom))
     FROM effis.current_burnt_area ba, public.admin_level_0 cnt
     WHERE cnt.name_en = country_txt 
     AND ST_Within(ba.geom, cnt.geom);  
END;
$$;

