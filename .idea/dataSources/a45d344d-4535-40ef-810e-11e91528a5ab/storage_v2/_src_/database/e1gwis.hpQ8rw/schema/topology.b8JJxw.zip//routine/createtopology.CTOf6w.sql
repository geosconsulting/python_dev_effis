create function createtopology(character varying, integer)
  returns integer
strict
language sql
as $$
SELECT topology.CreateTopology($1, $2, 0);
$$;

