create function hotspot_by_baid(integer)
  returns SETOF modis_viirs.hotspots_type
language plpgsql
as $$
declare 
  id_area_bruciata ALIAS FOR $1;
  tipo modis_viirs.hotspots_type;
  in_date date;
  out_date date;
  riga record;  
begin
   in_date := '2001-10-1'::date;
   out_date := '2017-12-31'::date;
   for riga in 
     SELECT hs.* 
     FROM effis.modis_hotspots hs, effis.archived_burnt_area ba
     WHERE ba.ba_id = id_area_bruciata 
     AND hs.acq_date BETWEEN in_date AND out_date
     AND ST_Within(hs.geom, ba.geom)   
    loop
     return next riga;
   end loop;   
   return;
end;
$$;

