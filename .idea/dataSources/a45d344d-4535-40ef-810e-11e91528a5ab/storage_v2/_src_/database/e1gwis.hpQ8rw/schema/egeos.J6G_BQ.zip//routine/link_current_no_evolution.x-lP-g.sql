create function link_current_no_evolution()
  returns TABLE(current_id bigint, date_current date, current_area_ha numeric)
language plpgsql
as $$
begin 
   return QUERY
     SELECT c.id,c.firedate,c.area_ha
     from egeos.current_ba c
     left outer join egeos.evolution_ba e ON (e.id=c.id)
     WHERE e.id is null
     ORDER BY c.id;
end;
$$;

