create function generate_annual_stats(year_str text)
  returns void
language plpgsql
as $$
declare 
  view_name text := 'ba_stats_' || year_str;
  start_date text := year_str || '-01-01';
  end_date text := year_str || '-12-31';
  query text := 'CREATE MATERIALIZED VIEW effis.' || view_name || ' AS 
		 SELECT a.name_en,
		    EXTRACT(YEAR FROM firedate::date) AS year_date,
		    EXTRACT(MONTH FROM firedate::date) AS month_date,
		    sum(st_area(b.geom::geography) * 0.0001::double precision) AS sum,
		    count(b.ba_id) AS count
		   FROM effis.archived_burnt_area b,
		    effis_countries a
		  WHERE b.firedate::date>=' || (start_date::text)::date || ' AND b.firedate::date<=' || (end_date::text)::date || ' AND st_intersects(b.geom, a.geom)
		  GROUP BY CUBE((year_date, month_date), a.name_en);';
begin
  execute query;
end;
$$;

